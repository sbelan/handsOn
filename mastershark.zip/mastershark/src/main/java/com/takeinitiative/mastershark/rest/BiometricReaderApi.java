package com.takeinitiative.mastershark.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.springframework.stereotype.Component;

import net.minidev.json.JSONObject;

/**
 * Biometric API.
 * 
 * @author Shrikant Belan.
 *
 */
@Path("/biometric")
@Produces({ MediaType.APPLICATION_JSON })
@Component
public class BiometricReaderApi {

	@Path("/{biometricflag}")
	@GET
	public Response getBiometricFlag(@PathParam("biometricflag") String biometricflag) {

		if (Boolean.valueOf(biometricflag)) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", "success");
			return Response.ok(jsonObject).build();
		} else {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("status", "failure");
			return Response.status(Status.BAD_REQUEST).entity(jsonObject).build();
		}

	}
}
