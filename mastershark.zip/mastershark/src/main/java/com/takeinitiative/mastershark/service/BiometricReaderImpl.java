package com.takeinitiative.mastershark.service;

public class BiometricReaderImpl implements BiometricReaderService {

}
