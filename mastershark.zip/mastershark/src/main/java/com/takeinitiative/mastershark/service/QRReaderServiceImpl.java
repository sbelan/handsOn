package com.takeinitiative.mastershark.service;

import javax.inject.Inject;
import javax.inject.Named;

import com.takeinitiative.mastershark.repository.CustomerDetailsRepository;

@Named
public class QRReaderServiceImpl implements QRReaderService{

	@Inject
	CustomerDetailsRepository CustomerDetailsRepository;
	
	@Override
	public void validateQRdata() {
		// TODO Auto-generated method stub
		CustomerDetailsRepository.findOne(1);
		
	}

}
