package com.takeinitiative.mastershark.service;

public interface BiometricReaderService {

	
}
