package com.takeinitiative.mastershark.service;

public interface QRReaderService {
	
	void validateQRdata();
}
