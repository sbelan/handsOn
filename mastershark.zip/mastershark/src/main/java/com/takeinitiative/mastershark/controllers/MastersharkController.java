package com.takeinitiative.mastershark.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MastersharkController {
	
	@RequestMapping("/atm")
    String index(){
        return "index";
    }

	@RequestMapping("/authtype")
    String page2(){
        return "authtype";
    }
	
	@RequestMapping("/qrcode")
    String qrcode(){
        return "qrcode";
    }
	
	@RequestMapping("/custinfo")
    String custinfo(){
        return "custinfo";
    }
	
}
