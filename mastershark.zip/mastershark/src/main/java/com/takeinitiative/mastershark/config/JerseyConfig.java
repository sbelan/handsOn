package com.takeinitiative.mastershark.config;

import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.server.ResourceConfig;

import com.fasterxml.jackson.jaxrs.json.JacksonJaxbJsonProvider;

/**
 * Jersey configuration class.
 * 
 * @author Shrikant Belan
 *
 */
public class JerseyConfig extends ResourceConfig {

	public JerseyConfig() {
		packages("com.takeinitiative.mastershark.rest");
		register(JacksonJaxbJsonProvider.class);
		register(JacksonFeature.class);
	}
}
