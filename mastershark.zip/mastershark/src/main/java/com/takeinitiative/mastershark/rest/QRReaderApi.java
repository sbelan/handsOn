package com.takeinitiative.mastershark.rest;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.takeinitiative.mastershark.service.QRReaderService;

@Path("/qr-data")
@Consumes({MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_JSON})
public class QRReaderApi {

	@Inject
	QRReaderService qrReaderService;
	
	@POST
	public Response getQRData(){
		qrReaderService.validateQRdata();
		return Response.status(Status.NO_CONTENT).build();
	}

}
